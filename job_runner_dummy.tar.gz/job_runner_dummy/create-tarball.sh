#!/bin/sh
set -eu

OUT=${1:-job_runner_dummy.tar.gz}

tar -czf "$OUT" Dockerfile run.sh
echo "wrote $OUT"
